import React, { useState, useRef, useEffect } from "react";
import "./App.css";

/* ------------------------------------------------------------------
   BACKEND API CONTRACT
   All training data / intent matching now lives in the Java backend.
   This file only sends the user's message to the backend and renders
   whatever comes back. Expected endpoints:

   GET  /api/intents/count
     -> { "count": 9 }

   POST /api/chat
     body: { "message": "hi" }
     -> { "reply": "Hello!", "tag": "greeting", "confidence": 1.0 }

   Change API_BASE_URL below to match wherever your Spring Boot
   (or other Java) server is running.
------------------------------------------------------------------- */
const API_BASE_URL = "http://localhost:8080/api";

export default function App() {
  const [messages, setMessages] = useState([
    {
      sender: "bot",
      text: "Hi! I'm Nova. Say hello to get started.",
      tag: "greeting",
      score: 1,
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [intentCount, setIntentCount] = useState(null);
  const scrollRef = useRef(null);

  // Fetch how many intents the backend was trained on, for the header
  useEffect(() => {
    fetch(`${API_BASE_URL}/intents/count`)
      .then((res) => res.json())
      .then((data) => setIntentCount(data.count))
      .catch(() => setIntentCount(null));
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  async function handleSend(e) {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;

    setMessages((prev) => [...prev, { sender: "user", text: trimmed }]);
    setInput("");
    setIsTyping(true);

    try {
      const res = await fetch(`${API_BASE_URL}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
      });

      if (!res.ok) throw new Error("Server error");

      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          text: data.reply,
          tag: data.tag,
          score: data.confidence,
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          text: "Couldn't reach the server. Is the Java backend running?",
          tag: "error",
          score: 0,
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  }

  return (
    <div className="app">
      <div className="chat-card">
        <header className="chat-header">
          <div className="bot-avatar" aria-hidden="true">
            N
          </div>
          <div className="header-text">
            <h1>Nova</h1>
            <p>
              {intentCount !== null
                ? `trained on ${intentCount} simple intents`
                : "connecting to backend..."}
            </p>
          </div>
          <div className="status-dot" title="online" />
        </header>

        <div className="chat-body" ref={scrollRef}>
          {messages.map((m, i) => (
            <div key={i} className={`message-row ${m.sender}`}>
              <div className="bubble">
                <p>{m.text}</p>
                {m.sender === "bot" && (
                  <span className="intent-tag">
                    matched: {m.tag} · {Math.round((m.score || 0) * 100)}%
                  </span>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="message-row bot">
              <div className="bubble typing">
                <span className="dot" />
                <span className="dot" />
                <span className="dot" />
              </div>
            </div>
          )}
        </div>

        <form className="chat-input" onSubmit={handleSend}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            aria-label="Type a message"
          />
          <button type="submit" disabled={!input.trim()}>
            Send
          </button>
        </form>
      </div>

      <p className="footnote">
        Demo chatbot — intent matching runs on a Java backend, this UI just talks to it over REST.
      </p>
    </div>
  );
}